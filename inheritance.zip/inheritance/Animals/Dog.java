//1. break into separate files
//2. add private data and constructor to Reptile
//3. add getter/setter to reptile
class Animal {
    private String species;
    private boolean hasHeartBeat;
    private double size;
    
    public Animal() { //default constructor, aka no-arg constructor
        species = "unknown";
        hasHeartBeat = true;
        size = 0.0;
        System.out.println("Animal constructor: " + species + ", " + hasHeartBeat + ", " + size);
    }
    
    public Animal(String s, boolean h, double sz) {
        species = s;
        hasHeartBeat = h;
        size = sz;
        System.out.println("Animal constructor: " + species + ", " + hasHeartBeat + ", " + size);
    }
    
    public String getSpecies() {return species;}
    public boolean getHasHeartBeat() {return hasHeartBeat;}
    public double getSize() {return size;}
    public void setSpecies(String s) {species = s;}
    public void setHasHeartBeat(boolean h) {hasHeartBeat = h;}
    public void setSize(double sz) {size = sz;}
    
}

class Mammal extends Animal {
    private String furrColor;
    
    public Mammal() {
        furrColor = "black";
        System.out.println("Mammal Constructor: " + furrColor);
    }
    
    public Mammal(String bl) {
        super("beluga whale", true, 20.0);
        furrColor = bl;
        System.out.println("Mammal Constructor: " + furrColor);
        
    }
    
    public String getFurrColor() {return furrColor;}
    public void setFurrColor(String fc) {furrColor = fc;}
}

class Reptile extends Animal {
    private boolean isCollubrid;
    
    public Reptile() {
        isCollubrid = true;
    }
    
    public Reptile(boolean isCol) {
        isCollubrid = isCol;
    }
    
    public boolean getIsCollubrid() {return isCollubrid;}
    public void setIsCollubrid(boolean isCol) {isCollubrid = isCol;}
}


public class Dog extends Mammal {
    
    public String name;
    public String breed;
    
    public Dog() {
        super("blue");
        name = "fido";
        breed = "labbet hound";
        System.out.println("Dog Constructor: " + name + ", " + breed);
    }
    
    public Dog(String nam, String brd) {
        name = nam;
        breed = brd;
    }
    
    public String getName() {return name;}
    public String getBreed() {return breed;}
    public void setName(String nam) {name = nam;}
    public void setBreed(String brd) {breed = brd;}
    
    public static void main(String args[]) {
        //Feel free to uncomment everything
        //Notice how the Dog constructor will automatically call
        //the parent Mammal one-arg constructor which will automatically
        //call the grandparent Animal default constructor
        
        //Animal a = new Animal();
        //Mammal m = new Mammal();
        Dog d = new Dog();
        d.setSize(100.0);
        System.out.println("Dog Size: " + d.getSize());
        
        Reptile r = new Reptile();
        r.setSpecies("Sinaloan Milksnake");
        System.out.println("Reptile: " + r.getSpecies());
        
        //System.out.println(m instanceof Animal);
        //System.out.println(d instanceof Mammal);
        //System.out.println(d instanceof Animal);
        //System.out.println(r.getBloodType());
    }
}