
public class Vehicle{
    private int numWheels;
    public Vehicle() {
        numWheels = 4;
    }
}