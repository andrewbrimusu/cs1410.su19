class Speed{
    
    private int value;
    public Speed() {
        value=25;
    }
    public int getValue() {return value;}
    public void setValue(int v) {value=v;}
    
}
